#include "../features.hpp"
#include "../../../dependencies/interfaces/c_global_vars_base.hpp"
#include "../../../dependencies/interfaces/i_client_entity_list.hpp"
#include "../../../dependencies/interfaces/i_client_state.hpp"
#include "../../../dependencies/interfaces/iv_engine_client.hpp"
#include "../../../dependencies/interfaces/i_surface.hpp"

void visuals::glowesp()
{
	if (!variables::glowesp)
		return;
	if (!interfaces::engine->is_connected() || !interfaces::engine->is_in_game())
		return;
	if (!csgo::local_player)
		return;
	for (int i = 0; i < interfaces::glow_manager->size; ++i)
	{
		if (interfaces::glow_manager->objects[i].unused() || !interfaces::glow_manager->objects[i].entity)
			continue;

		auto& glowEnt = interfaces::glow_manager->objects[i];
		auto pCSPlayer = reinterpret_cast<player_t*>(glowEnt.entity);
		auto clientclass = reinterpret_cast<c_client_class*>(pCSPlayer->client_class());
		if (!pCSPlayer)
			continue;
		if (pCSPlayer == csgo::local_player)
			continue;
		if (pCSPlayer->dormant())
			continue;
		if (!(pCSPlayer->is_alive() && pCSPlayer->health() > 0))
			continue;
		if (clientclass->class_id == ccsplayer)
		{
			if (pCSPlayer->team() == csgo::local_player->team() && variables::showteamesp)
			{
				glowEnt.set(0.0f, 1.0f, 1.0f, 0.6f);
			}
			else if (pCSPlayer->team() != csgo::local_player->team())
			{
				glowEnt.set(1.0f, 0.0f, 1.0f, 0.6f); // 255 RGB = 1 if you want specific values compare it to rgb
			}
		}
	}
}

