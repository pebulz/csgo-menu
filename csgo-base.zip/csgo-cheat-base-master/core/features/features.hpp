#pragma once
#include "../../dependencies/utilities/csgo.hpp"
#include "../menu/variables.hpp"


namespace misc {
	void rankreveal();
	void recoil_crosshair();
	void sniper_crosshair();
	

	namespace movement {
		void bunny_hop(c_usercmd* cmd);
	};
}

namespace visuals {
	void glowesp();

}
