#pragma once 
#include "../features.hpp"
#include "../../../dependencies/interfaces/i_client_state.hpp"
#include "../../../dependencies/interfaces/i_input.hpp"


void misc::movement::bunny_hop(c_usercmd* cmd) {
	if (!variables::bunnyhop)
		return;

	const int move_type = csgo::local_player->move_type();

	if (move_type == movetype_ladder || move_type == movetype_noclip || move_type == movetype_observer)
		return;

	if (!(csgo::local_player->flags() & fl_onground))
		cmd->buttons &= ~in_jump;
};

void misc::rankreveal() {
	if (!variables::rankreveal)
		return;

	if (GetAsyncKeyState(VK_TAB))
		interfaces::client->dispatch_user_message(cs_um_serverrankrevealall, 0, 0, nullptr);
}

void misc::recoil_crosshair() {
	static auto cl_crosshair_recoil = interfaces::console->get_convar("cl_crosshair_recoil");
	cl_crosshair_recoil->set_value(variables::recoil_crosshair ? 1 : 0);
}

void misc::sniper_crosshair() {
	if (!csgo::local_player)
		return;

	static auto weapon_debug_spread_show = interfaces::console->get_convar("weapon_debug_spread_show");

	if (csgo::local_player && csgo::local_player->health() > 0) {
		weapon_debug_spread_show->set_value(csgo::local_player->is_scoped() || !variables::sniper_crosshair ? 0 : 3);
	}
}
