#pragma once

namespace variables {
	// inline float test_float = 0.f;
	inline bool glowesp = false;
	inline bool rankreveal = false;
	inline bool recoil_crosshair = false;
	inline bool sniper_crosshair = false;
	inline bool bunnyhop = false;
	inline bool showteamesp = false;
	namespace menu {
		inline bool opened = false;
		inline int x = 140, y = 140;
		inline int w = 400, h = 300;
	
	}
}