


# info [![Build status](https://ci.appveyor.com/api/projects/status/s9yhmm4ru6ywfsyt?svg=true)](https://ci.appveyor.com/project/designer1337/csgo-cheat-base) [![C++](https://img.shields.io/badge/language-C%2B%2B-%23f34b7d.svg)](https://en.wikipedia.org/wiki/C%2B%2B) [![CS:GO](https://img.shields.io/badge/game-CS%3AGO-yellow.svg)](https://store.steampowered.com/app/730/CounterStrike_Global_Offensive/) [![Windows](https://img.shields.io/badge/platform-Windows-0078d7.svg)](https://en.wikipedia.org/wiki/Microsoft_Windows)
updated version of: https://github.com/alphauc/sdk with some improvements, eg. undetected hooking library

# credits
1. alpha
2. harcuz
3. wando


# media
![image](https://i.imgur.com/7rKZHUL.png)
